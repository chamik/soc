# Rozřazovák ✨ meta repo ✨
Tady uchovávám zdroj pro moji středoškolskou odbornou činnost [Rozřazovák](https://github.com/chamik/rozrazovak).

Template byl ~~ukraden~~ s úpravami vypůjčen z https://github.com/pajasry/gjp-soc-template.